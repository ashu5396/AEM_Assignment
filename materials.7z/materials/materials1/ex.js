$(document).ready(function(){
var $checkBoxCheck=$("input[type='checkbox']")
$checkBoxCheck.change(function () {
  if ($(this).is(":checked")) {
      $(".apply-button").removeAttr('disabled');
  }
  else {
      var isChecked = false;
      $checkBoxCheck.each(function () {
          if ($(this).is(":checked")) {
            $(".apply-button").removeAttr('disabled');
              isChecked = true;
          }
      });
      if (!isChecked) {
        $(".apply-button").attr('disabled', 'disabled');
      }
  }
})
});