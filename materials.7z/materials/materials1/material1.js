$( document ).ready(function() {
$('#apply_filter').hide();

$('#filter_click').click(function(){
  $('#hide_filters').hide();
  $('#apply_filter').show();
})


    $('#main-div').hide();
  var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    //   debugger;
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}


$('#more_filters').on('click',function(){
    
    $('.card-main').hide();
    $('#main-div').show();
    $('.filter h5').text("More Filter");
    $('#more_filters').hide();
    $('#search_filter').hide();
    $('.cross-button').css('display','block');

    

})
   

$('.cross-button').on('click',function(){
    
    $('.card-main').show();
    $('#main-div').hide();
    $('.filter h5').text("Filter");
    $('#more_filters').show();
    $('#search_filter').show();
    $('.cross-button').css('display','none');

    

})

// $('#clearall').click(function() {
//     $(":checkbox").removeAttr("checked", "checked");
// });
var $checkBoxCheck=$("input[type='checkbox']")
$checkBoxCheck.change(function () {
  if ($(this).is(":checked")) {
      $(".apply-button").removeAttr('disabled');
  }
  else {
      var isChecked = false;
      $checkBoxCheck.each(function () {
          if ($(this).is(":checked")) {
            $(".apply-button").removeAttr('disabled');
              isChecked = true;
          }
      });
      if (!isChecked) {
        $(".apply-button").attr('disabled', 'disabled');
      }
  }
}) 

});

